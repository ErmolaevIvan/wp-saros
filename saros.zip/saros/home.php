<?php
get_header();
?>

    <main>

        <!-- Slider main -->
        <div class="slider__wrappers main__slider">
            <div class="swiper-container slider__images">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="img/img1.png" alt="">
                    </div>
                    <div class="swiper-slide">
                        <img src="img/img2.png" alt="">
                    </div>
                    <div class="swiper-slide">
                        <img src="img/img3.png" alt="">
                    </div>
                    <div class="swiper-slide">
                        <img src="img/img4.png" alt="">
                    </div>
                    <div class="swiper-slide">
                        <img src="img/img5.png" alt="">
                    </div>
                </div>
            </div>

            <div class="slider__text-wrapper">
                <div class="swiper-container slider__text">
                    <div class="swiper-wrapper">
                        <!-- slide -->
                        <div class="swiper-slide">
                            <div class="slider__text-body">
                                <div class="slider__text-collection">Outdoor collection</div>
                                <div class="slider__text-title"><span>Lighting</span>systems</div>
                                <div class="slider__text-detail"><a href="#">Detail</a></div>
                            </div>
                        </div>
                        <!-- end slide -->
                        <!-- slide -->
                        <div class="swiper-slide">
                            <div class="slider__text-body">
                                <div class="slider__text-collection">Outdoor collection</div>
                                <div class="slider__text-title"><span>Streetlight</span>bollards</div>
                                <div class="slider__text-detail"><a href="#">Detail</a></div>
                            </div>
                        </div>
                        <!-- end slide -->
                        <!-- slide -->
                        <div class="swiper-slide">
                            <div class="slider__text-body">
                                <div class="slider__text-collection">Outdoor collection</div>
                                <div class="slider__text-title"><span>Modern style</span>luminaries</div>
                                <div class="slider__text-detail"><a href="#">Detail</a></div>
                            </div>
                        </div>
                        <!-- end slide -->
                        <!-- slide -->
                        <div class="swiper-slide">
                            <div class="slider__text-body">
                                <div class="slider__text-collection">Outdoor collection</div>
                                <div class="slider__text-title"><span>Classic Style</span>street luminaries</div>
                                <div class="slider__text-detail"><a href="#">Detail</a></div>
                            </div>
                        </div>
                        <!-- end slide -->
                        <!-- slide -->
                        <div class="swiper-slide">
                            <div class="slider__text-body">
                                <div class="slider__text-collection">Outdoor collection</div>
                                <div class="slider__text-title"><span>linear</span>luminaries</div>
                                <div class="slider__text-detail"><a href="#">Detail</a></div>
                            </div>
                        </div>
                        <!-- end slide -->
                    </div>
                    <div class="slider-controls">
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-next"><i class="icon-right"></i></div>
                        <div class="swiper-button-prev"><i class="icon-left"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End slider main -->

        <section class="project__slider">
            <div class="swiper-container slider-projects">
                <div class="swiper-wrapper">
                    <!-- slide -->
                    <div class="swiper-slide">
                        <img src="img/project-top/project-1.jpg" alt="">
                    </div>
                    <!-- end slide -->
                    <!-- slide -->
                    <div class="swiper-slide">
                        <img src="img/project-top/project-2.jpg" alt="">
                    </div>
                    <!-- end slide -->
                    <!-- slide -->
                    <div class="swiper-slide">
                        <img src="img/project-top/project-3.jpg" alt="">
                    </div>
                    <!-- end slide -->
                </div>
                <div class="slider-controls">
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"><i class="icon-right"></i></div>
                    <div class="swiper-button-prev"><i class="icon-left"></i></div>
                </div>
            </div>
        </section>

        <section class="trails__slider">
            <div class="title"><h2>Trails</h2></div>
            <div class="swiper-container slider-trails">
                <div class="swiper-wrapper">
                    <!-- slide -->
                    <div class="swiper-slide">
                        <a href="#">
                            <img src="img/trail-1.png" alt="">
                            <div class="trails__slider-body">
                                <div class="trails__slider-title">Trail</div>
                            </div>
                        </a>
                    </div>
                    <!-- end slide -->
                    <!-- slide -->
                    <div class="swiper-slide">
                        <a href="#">
                            <img src="img/trail-2.png" alt="">
                            <div class="trails__slider-body">
                                <div class="trails__slider-title">Trail</div>
                            </div>
                        </a>
                    </div>
                    <!-- end slide -->
                    <!-- slide -->
                    <div class="swiper-slide">
                        <a href="#">
                            <img src="img/trail-3.png" alt="">
                            <div class="trails__slider-body">
                                <div class="trails__slider-title">Trail</div>
                            </div>
                        </a>
                    </div>
                    <!-- end slide -->
                    <!-- slide -->
                    <div class="swiper-slide">
                        <a href="#">
                            <img src="img/trail-4.png" alt="">
                            <div class="trails__slider-body">
                                <div class="trails__slider-title">Trail</div>
                            </div>
                        </a>
                    </div>
                    <!-- end slide -->

                </div>
                <div class="slider-controls">
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"><i class="icon-right"></i></div>
                    <div class="swiper-button-prev"><i class="icon-left"></i></div>
                </div>
            </div>
        </section>

        <section class="products__slider">
            <!-- Slider products -->
            <div class="slider__wrappers">
                <div class="swiper-container slider__images">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="img/indor-1.png" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="img/indor-2.png" alt="">
                        </div>
                        <div class="swiper-slide">
                            <img src="img/indor-3.png" alt="">
                        </div>
                    </div>
                </div>

                <div class="slider__text-wrapper">
                    <div class="swiper-container slider__text">
                        <div class="swiper-wrapper">
                            <!-- slide -->
                            <div class="swiper-slide">
                                <div class="slider__text-body">
                                    <div class="slider__text-collection">indoor collection</div>
                                    <div class="slider__text-title"><span>Moebius</span></div>
                                    <div class="slider__text-detail"><a href="#">Detail</a></div>
                                </div>
                            </div>
                            <!-- end slide -->
                            <!-- slide -->
                            <div class="swiper-slide">
                                <div class="slider__text-body">
                                    <div class="slider__text-collection">indoor collection</div>
                                    <div class="slider__text-title"><span>Twist</span></div>
                                    <div class="slider__text-detail"><a href="#">Detail</a></div>
                                </div>
                            </div>
                            <!-- end slide -->
                            <!-- slide -->
                            <div class="swiper-slide">
                                <div class="slider__text-body">
                                    <div class="slider__text-collection">indoor collection</div>
                                    <div class="slider__text-title"><span>Bagel</span></div>
                                    <div class="slider__text-detail"><a href="#">Detail</a></div>
                                </div>
                            </div>
                            <!-- end slide -->
                        </div>
                        <div class="slider-controls">
                            <div class="swiper-pagination"></div>
                            <div class="swiper-button-next"><i class="icon-right"></i></div>
                            <div class="swiper-button-prev"><i class="icon-left"></i></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End slider products -->
        </section>

        <section class="project__slider">
            <div class="swiper-container slider-projects">
                <div class="swiper-wrapper">
                    <!-- slide -->
                    <div class="swiper-slide">
                        <img src="img/project-bottom/project-1.jpg" alt="">
                    </div>
                    <!-- end slide -->
                    <!-- slide -->
                    <div class="swiper-slide">
                        <img src="img/project-bottom/project-2.jpg" alt="">
                    </div>
                    <!-- end slide -->
                    <!-- slide -->
                    <div class="swiper-slide">
                        <img src="img/project-bottom/project-3.jpg" alt="">
                    </div>
                    <!-- end slide -->
                    <!-- slide -->
                    <div class="swiper-slide">
                        <img src="img/project-bottom/project-4.jpg" alt="">
                    </div>
                    <!-- end slide -->
                </div>
                <div class="slider-controls">
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"><i class="icon-right"></i></div>
                    <div class="swiper-button-prev"><i class="icon-left"></i></div>
                </div>
            </div>
        </section>

    </main>

<?php
get_sidebar();
get_footer();
