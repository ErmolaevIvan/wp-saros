<?php
if (!defined('ABSPATH')){
    exit;
}

register_nav_menus(array(
    'primary' => 'Header',
    'secondary' => 'Footer'
));