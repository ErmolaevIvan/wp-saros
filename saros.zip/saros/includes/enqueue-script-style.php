<?php
if (!defined('ABSPATH')){
    exit;
}

/**
 * Enqueue scripts and styles.
 */
add_action( 'wp_enqueue_scripts', 'saros_styles' );
function saros_styles() {
    wp_enqueue_style('swiper-slider', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css', null, 'all');
    wp_enqueue_style( 'saros-style', get_stylesheet_uri(), array(), _S_VERSION );
}

add_action( 'wp_enqueue_scripts', 'saros_scripts' );
function saros_scripts() {
    wp_enqueue_script( 'saros-navigation', get_template_directory_uri() . 'assets/js/navigation.js', array(), _S_VERSION, true );
    wp_enqueue_script('swiper-slider', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array(), false, true);
    wp_enqueue_script('app-script', get_template_directory_uri() . '/assets/js/app.min.js', array(), false, true);
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
