<?php
if (!defined('ABSPATH')){
    exit;
}

use Carbon_Fields\Container;
use Carbon_Fields\Field;


// Add second options page under 'Basic Options'
Container::make( 'theme_options', __( 'Theme Options' ) )
    ->add_fields( array(
        Field::make( 'text', 'crb_basic_address', __( 'Address' ) ),
        Field::make( 'text', 'crb_basic_phone', __( 'Phone' ) )
            ->set_width(50),
        Field::make( 'text', 'crb_basic_email', __( 'E-mail' ) )
            ->set_width(50),
    ) );


